import pygame
pygame.init()
# GetConstants returns a list of values from settings.txt neccessary for the tron2.py file to function
def GetConstants():
    USR = open("settings.txt", 'r')
    item = USR.readline()
    SCRNWDTH = int(item.rstrip('WIDTH_OF_THE_WINDOW\n'))
    item = USR.readline()
    SCRNHGHT = int(item.rstrip('HEIGHT_OF_THE_WINDOW\n'))
    item = USR.readline()
    TRL = int(item.rstrip('NUMBER_OF_TRAILING_LINES\n'))
    item = USR.readline()
    CLCKRT = int(item.rstrip('FRAMES_PER_SECOND\n'))
    item = USR.readline()
    playercol = list(item.rstrip('PLAYERS_3_RED_5_BLUE_7_GREEN_OTHER_WHITE\n'))
    #print playercol
    PLYRS = []
    for num in range(len(playercol)):
        if playercol[num] == '3':
            PLYRS.append('red')
        elif playercol[num] == '5':
            PLYRS.append('blue')
        elif playercol[num] == '7':
            PLYRS.append('green')
        else:
            PLYRS.append('white')
    #print PLYRS
    item = USR.readline()
    playercol = list(item.rstrip('CONTROLS_IN_RESPECT_TO_EACH_PLAYER_NUMBERS_ARE_ARROW_KEYS\n'))
    return [SCRNWDTH, SCRNHGHT,TRL,CLCKRT,PLYRS]


def GetMap(name = "defmap.txt"):
    MP = [None, None, None]
    
    USR = open(name, 'r')
    item = USR.readline()
    itemyloc = 1
    while item != None:
        for position in len(item):
            if item[position] != "0":
                if item[position] == 1:
                    MP[1].append(point(position *12, itemy * 12))
                if item[position] == 2:
                    MP[2].append(point(position *12, itemy *12))
                

        itemy += 1
        item = USR.readline()
    return MP


    
x = GetConstants()
print x
x = GetMap()
print x
