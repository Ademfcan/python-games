import pygame, settingsetter.py, sys

pygame.init()
se_ = settingsetter.GetConstants()
SCRNWDTH = se_[0]
SCRNHGHT = se_[1]
TRL_LIMIT = se_[2]
CLOCKRATE = se_[3]
PLYRS = []
for color in se_[4]:
    PLYRS.append(se_[4][color])
SCRN = pygame.display.set_mode((SCRNWDTH,SCRNHGHT), pygame.FULLSCREEN | pygame.DOUBLEBUF | pygame.NOFRAME)
UP = pygame.K_UP
DOWN = pygame.K_DOWN
LEFT = pygame.K_LEFT
RIGHT = pygame.K_RIGHT
class LightBike(pygame.sprite.Sprite):
    def __init__(self, xpos, ypos, controls = [], color = "green", facing = "R"):
        pygame.sprite.Sprite.__init__(self)
        self.col = color
        self.x = xpos
        self.y = ypos
        self.sprite_ref = "lights/" , color,  facing, ".gif"
        self.image = pygame.image.load(self.sprite_ref)
        self.rect = self.image.get_rect()
        self.rect.center = (self.x, self.y)
        self.speed = 12
        self.trailing = True
        self.facing = facing
        self.invulnerable= False
###############################################################
    def action(self):
        if self.trailing == True:
            self.trailing = False
        else:
            self.trailing = True
###############################################################
    def movedown(self):
        self.rect.centery += self.speed
    def moveup(self):
        self.rect.centery -= self.speed
    def moveleft(self):
        self.rect.centerx -= self.speed
    def moveright(self):
        self.rect.centerx += self.speed
###############################################################        
    def update(self ):
        if self.controls:
            if pygame.key.get_pressed()[self.controls[0]]:
                self.dir = "U"
            elif pygame.key.get_pressed()[self.controls[1]]:
                self.dir = "L"
            elif pygame.key.get_pressed()[self.controls[2]]:
                self.dir = "D"
            elif pygame.key.get_pressed()[self.controls[3]]:
                self.dir = "R"
            elif pygame.key.get_pressed()[self.controls[4]]:
                self.action()
        else:
            self.action() #placeholder. remove this < line when AI is written
            #self.AI(): #TODO make AI function
        if self.facing == "R":
            self.moveright()
        elif self.facing == "U":
            self.moveup()
        elif self.facing == "D":
            self.movedown()
        elif self.facing == "L":
            self.moveleft()
        self.sprite_ref = str("lights/" & self.col & self.facing & ".gif")
        if self.invulnerable == False:
            #CHECK FOR COLLISIONS HERE. CALL STOP FUNCTION TO DESTROY LIGHTCYCLE FROM THE SPRITE GROUP.
            self.action()#if collision , then display death animation here.
        #and remember to add position to wall class
        return self.rect.center
    
###############################################################

###############################################################
class Wall(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self
class Player:
    def __init__(self):
        self.vehicle = LightBike(300, 300, [UP, LEFT, DOWN, RIGHT] )
        self.walls = list()
    def update(self):
        self.walls.append(self.vehicle.update())
        
        
