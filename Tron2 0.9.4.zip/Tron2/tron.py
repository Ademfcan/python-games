import pygame, sys

pygame.init()
Winw = 5
Winh = 3
SPEED = 12
WINDOWW = int(20 * SPEED * Winw)
WINDOWH = int(20 * SPEED * Winh)
w = 0
x = 0
y = 0
z = 0

screen = pygame.display.set_mode((WINDOWW, WINDOWH), pygame.DOUBLEBUF | pygame.NOFRAME | pygame.FULLSCREEN)
TRAIL_LIMIT = 180
CLOCKRATE = 25

class Wall(pygame.sprite.Sprite):
    def __init__(self, xloc, yloc):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("Wall.png")
        self.rect = self.image.get_rect()
        self.rect.center = (xloc, yloc)
    
class LightBike(pygame.sprite.Sprite):
    def __init__(self):
        self.point = 0
        pygame.sprite.Sprite.__init__(self)
        self.sprite_reference = "gliders/redR.png"
        self.image = pygame.image.load(self.sprite_reference)
        self.rect = self.image.get_rect()
        self.rect.center = (SPEED,SPEED)
        self.prev_pos = []
        self.speed = SPEED
        self.dir = "right"
        self.living = True
    def begin(self):
        self.living = True
        self.prev_pos = []
        self.dir = "right"
        self.rect.centerx = SPEED
        self.rect.centery = SPEED
        self.sprite_reference = "gliders/redR.png"
    def update(self):
        self.x = SPEED
        self.y = SPEED
        if self.living:
            
            self.prev_pos.append(self.rect.center)
# Sets the self.dir variable. Helps ensure constant movement despite a player not pressing a button
            if pygame.key.get_pressed()[pygame.K_RIGHT]:
                    self.dir = "right"
                    self.sprite_reference = "gliders/redR.png"
            elif pygame.key.get_pressed()[pygame.K_DOWN]:
                    self.dir = "down"
                    self.sprite_reference = "gliders/redD.png"
            elif pygame.key.get_pressed()[pygame.K_LEFT]:
                    self.dir = "left"
                    self.sprite_reference = "gliders/redL.png"
            elif pygame.key.get_pressed()[pygame.K_UP]:
                    self.dir = "up"
                    self.sprite_reference = "gliders/redU.png"
# Moves the Character's bike              
            if self.dir == "right":
                self.moveright()
                if self.rect.center in lb.prev_pos or self.rect.center in lb2.prev_pos or self.rect.center in lb3.prev_pos or self.rect.center in lb4. prev_pos:
                    Stop(self)
            if self.dir == "down":
                self.movedown()
                if self.rect.center in lb.prev_pos or self.rect.center in lb2.prev_pos or self.rect.center in lb3.prev_pos or self.rect.center in lb4. prev_pos:
                    Stop(self)
            if self.dir == "left":
                self.moveleft()
                if self.rect.center in lb.prev_pos or self.rect.center in lb2.prev_pos or self.rect.center in lb3.prev_pos or self.rect.center in lb4. prev_pos:
                    Stop(self)
            if self.dir == "up":
                self.moveup()
                if self.rect.center in lb.prev_pos or self.rect.center in lb2.prev_pos or self.rect.center in lb3.prev_pos or self.rect.center in lb4. prev_pos:
                    Stop(self)
# Actually sets the sprite, using the reference
        else:
            pygame.draw.circle(screen, (255, 30, 20), self.rect.center, 12, 1)
            self.sprite_reference = "transparent.png"
            if len(self.prev_pos) > 0:
                self.prev_pos.pop(0)
        if len(self.prev_pos) > 1:
            pygame.draw.aalines(screen,(230, 150, 20),False,self.prev_pos)
             
        if len(self.prev_pos) > TRAIL_LIMIT:
            self.prev_pos.pop(0)
        
        self.image = pygame.image.load(self.sprite_reference)
        
    def movedown(self):
        self.rect.centery += self.speed
    def moveup(self):
        self.rect.centery -= self.speed
    def moveleft(self):
        self.rect.centerx -= self.speed
    def moveright(self):
        self.rect.centerx += self.speed
    def addpoints(self):
        self.point += 10
        
        
class LightBike2(pygame.sprite.Sprite):
    def __init__(self):
        self.point = 0
        pygame.sprite.Sprite.__init__(self)
        self.sprite_reference = "gliders/blueD.png"
        self.image = pygame.image.load(self.sprite_reference)
        self.rect = self.image.get_rect()
        self.rect.center = (WINDOWW- SPEED, SPEED)
        self.prev_pos = []
        self.speed = SPEED
        self.dir = "down"
        self.living = True
    def begin(self):
        self.living = True
        self.prev_pos = []
        self.dir = "down"
        self.rect.centerx = WINDOWW - SPEED
        self.rect.centery = SPEED
        self.sprite_reference = "gliders/blueD.png"
    def update(self):
        self.x = WINDOWW - SPEED
        self.y = SPEED
        if self.living:
            
            self.prev_pos.append(self.rect.center)
            
            if pygame.key.get_pressed()[pygame.K_d]:
                    self.dir = "right"
                    self.sprite_reference = "gliders/blueR.png"
              
                    
            elif pygame.key.get_pressed()[pygame.K_s]:
                    self.dir = "down"
                    self.sprite_reference = "gliders/blueD.png"
      
                    
            elif pygame.key.get_pressed()[pygame.K_a]:
                    self.dir = "left"
                    self.sprite_reference = "gliders/blueL.png"
               
                    
            elif pygame.key.get_pressed()[pygame.K_w]:
                    self.dir = "up"
                    self.sprite_reference = "gliders/blueU.png"
              
            if self.dir == "right":
                self.moveright()
                if self.rect.center in lb.prev_pos or self.rect.center in lb2.prev_pos or self.rect.center in lb3.prev_pos or self.rect.center in lb4. prev_pos:
                    Stop(self)
            if self.dir == "down":
                self.movedown()
                if self.rect.center in lb.prev_pos or self.rect.center in lb2.prev_pos or self.rect.center in lb3.prev_pos or self.rect.center in lb4. prev_pos:
                    Stop(self)
            if self.dir == "left":
                self.moveleft()
                if self.rect.center in lb.prev_pos or self.rect.center in lb2.prev_pos or self.rect.center in lb3.prev_pos or self.rect.center in lb4. prev_pos:
                    Stop(self)
            if self.dir == "up":
                self.moveup()
                if self.rect.center in lb.prev_pos or self.rect.center in lb2.prev_pos or self.rect.center in lb3.prev_pos or self.rect.center in lb4. prev_pos:
                    Stop(self)
        else:
            pygame.draw.circle(screen, (230, 0, 255), self.rect.center, 12, 1)
            self.sprite_reference = "transparent.png"
            if len(self.prev_pos) > 0:
                self.prev_pos.pop(0)
        if len(self.prev_pos) > 1:
            pygame.draw.aalines(screen,(230, 0, 255),False,self.prev_pos)
             
        if len(self.prev_pos) > TRAIL_LIMIT:
            self.prev_pos.pop(0)
        
        self.image = pygame.image.load(self.sprite_reference)
        
    def movedown(self):
        self.rect.centery += self.speed
    def moveup(self):
        self.rect.centery -= self.speed
    def moveleft(self):
        self.rect.centerx -= self.speed
    def moveright(self):
        self.rect.centerx += self.speed
    def addpoints(self):
        self.point += 10

class LightBike3(pygame.sprite.Sprite):
    def __init__(self):
        self.point = 0
        pygame.sprite.Sprite.__init__(self)
        self.sprite_reference = "gliders/greenU.png"
        self.image = pygame.image.load(self.sprite_reference)
        self.rect = self.image.get_rect()
        self.rect.center = (SPEED, WINDOWH- SPEED)
        self.prev_pos = []
        self.speed = SPEED
        self.dir = "up"
        self.living = True
    def begin(self):
        self.living = True
        self.prev_pos = []
        self.dir = "up"
        self.rect.centerx = SPEED
        self.rect.centery = WINDOWH - SPEED
        self.sprite_reference = "gliders/greenU.png"
    def update(self):
        self.x = SPEED
        self.y = WINDOWH- SPEED
        if self.living:
            self.prev_pos.append(self.rect.center)
            
            if pygame.key.get_pressed()[pygame.K_l]:
                    self.dir = "right"
                    self.sprite_reference = "gliders/greenR.png"
            elif pygame.key.get_pressed()[pygame.K_k]:
                    self.dir = "down"
                    self.sprite_reference = "gliders/greenD.png"
            elif pygame.key.get_pressed()[pygame.K_j]:
                    self.dir = "left"
                    self.sprite_reference = "gliders/greenL.png"
            elif pygame.key.get_pressed()[pygame.K_i]:
                    self.dir = "up"
                    self.sprite_reference = "gliders/greenU.png"
            if self.dir == "right":
                self.moveright()
                if self.rect.center in lb.prev_pos or self.rect.center in lb2.prev_pos or self.rect.center in lb3.prev_pos or self.rect.center in lb4. prev_pos:
                    Stop(self)
            if self.dir == "down":
                self.movedown()
                if self.rect.center in lb.prev_pos or self.rect.center in lb2.prev_pos or self.rect.center in lb3.prev_pos or self.rect.center in lb4. prev_pos:
                    Stop(self)
            if self.dir == "left":
                self.moveleft()
                if self.rect.center in lb.prev_pos or self.rect.center in lb2.prev_pos or self.rect.center in lb3.prev_pos or self.rect.center in lb4. prev_pos:
                    Stop(self)
            if self.dir == "up":
                self.moveup()
                if self.rect.center in lb.prev_pos or self.rect.center in lb2.prev_pos or self.rect.center in lb3.prev_pos or self.rect.center in lb4. prev_pos:
                    Stop(self)
                    
        else:
            pygame.draw.circle(screen, (60, 230, 0), self.rect.center, 12, 1)
            self.sprite_reference = "transparent.png"
            if len(self.prev_pos) > 0:
                self.prev_pos.pop(0)
        if len(self.prev_pos) > 1:
            pygame.draw.aalines(screen,(60, 230, 0),False,self.prev_pos)
             
        if len(self.prev_pos) > TRAIL_LIMIT:
            self.prev_pos.pop(0)
        
        self.image = pygame.image.load(self.sprite_reference)       
    def movedown(self):
        self.rect.centery += self.speed
    def moveup(self):
        self.rect.centery -= self.speed
    def moveleft(self):
        self.rect.centerx -= self.speed
    def moveright(self):
        self.rect.centerx += self.speed
    def addpoints(self):
        self.point += 10



        

class LightBike4(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.sprite_reference = "gliders/whiteL.png"
        self.image = pygame.image.load(self.sprite_reference)
        self.rect = self.image.get_rect()
        self.rect.center = (WINDOWW- SPEED, WINDOWH - SPEED)
        self.prev_pos = []
        self.speed = SPEED
        self.dir = "L"
        self.living = True
        self.F = 1
        self.H = 1
        self.G = 0
    def begin(self):
        self.living = True
        self.prev_pos = []
        self.dir = "L"
        self.rect.centerx = WINDOWW - SPEED
        self.rect.centery = WINDOWH - SPEED
        self.sprite_reference = "gliders/whiteL.png"
    def check(self):
        if not pygame.key.get_pressed()[pygame.K_f]:
            self.F = 1
        if not pygame.key.get_pressed()[pygame.K_h]:
            self.H = 1
    def update(self):
        self.x = WINDOWW - SPEED
        self.y = WINDOWH - SPEED
        if self.living:
            
            self.prev_pos.append(self.rect.center)
            #if not pygame.key.get_pressed()[pygame.K_f]:
              #  self.F = 1
            #if not pygame.key.get_pressed()[pygame.K_h]:
             #   self.H = 1
            #if not pygame.key.get_pressed()[pygame.K_g]:
             #   self.G = 0
            #if pygame.key.get_pressed()[pygame.K_g]:
             #   self.G = 1
# Sets the self.dir variable. Helps ensure constant movement despite a player not pressing a button
            #if pygame.key.get_pressed()[pygame.K_h]:
            if pygame.key.get_pressed()[pygame.K_h]:
                    self.dir = "R"
                    self.sprite_reference = "gliders/whiteR.png"
            elif pygame.key.get_pressed()[pygame.K_g]:
                    self.dir = "D"
                    self.sprite_reference = "gliders/whiteD.png"
            elif pygame.key.get_pressed()[pygame.K_f]:
                    self.dir = "L"
                    self.sprite_reference = "gliders/whiteL.png"
            elif pygame.key.get_pressed()[pygame.K_t]:
                    self.dir = "U"
                    self.sprite_reference = "gliders/whiteU.png"
                    
            self.sprite_reference = "gliders/white" + self.dir + ".png"
# Moves the Character's bike              
            if self.dir == "R":
                self.moveright()
                if self.rect.center in lb.prev_pos or self.rect.center in lb2.prev_pos or self.rect.center in lb3.prev_pos or self.rect.center in lb4. prev_pos:
                    Stop(self)
            if self.dir == "D":
                self.movedown()
                if self.rect.center in lb.prev_pos or self.rect.center in lb2.prev_pos or self.rect.center in lb3.prev_pos or self.rect.center in lb4. prev_pos:
                    Stop(self)
            if self.dir == "L":
                self.moveleft()
                if self.rect.center in lb.prev_pos or self.rect.center in lb2.prev_pos or self.rect.center in lb3.prev_pos or self.rect.center in lb4. prev_pos:
                    Stop(self)
            if self.dir == "U":
                self.moveup()
                if self.rect.center in lb.prev_pos or self.rect.center in lb2.prev_pos or self.rect.center in lb3.prev_pos or self.rect.center in lb4. prev_pos:
                    Stop(self)
# Actually sets the sprite, using the reference
        else:
            pygame.draw.circle(screen, (230, 230, 230), self.rect.center, 12, 1)
            self.sprite_reference = "transparent.png"
            if len(self.prev_pos) > 0:
                self.prev_pos.pop(0)
        if len(self.prev_pos) > 1:
            pygame.draw.aalines(screen,(230, 230, 230),False,self.prev_pos)
        if len(self.prev_pos) > TRAIL_LIMIT:
            self.prev_pos.pop(0)
        
        self.image = pygame.image.load(self.sprite_reference)
        if not pygame.key.get_pressed()[pygame.K_f]:
                self.F = 1
        if not pygame.key.get_pressed()[pygame.K_h]:
                self.H = 1
    def movedown(self):
        self.rect.centery += self.speed
    def moveup(self):
        self.rect.centery -= self.speed
    def moveleft(self):
        self.rect.centerx -= self.speed
    def moveright(self):
        self.rect.centerx += self.speed
    def addpoints(self):
        self.point += 10





clock = pygame.time.Clock()
Begintimer = pygame.time.Clock()
lb = LightBike()

lb2 = LightBike2()
lb3 = LightBike3()
lb4 = LightBike4()
Sprites = pygame.sprite.Group(lb, lb2, lb3,lb4)
Corners = []
Corners.append((1,1))
Corners.append((WINDOWW- 2, 1))
Corners.append((WINDOWW-2, WINDOWH-2))
Corners.append((1, WINDOWH-2))
Corners.append((1,1))
Stats = pygame.font.Font("fonts/B.ttf", int(Winw * 4))
Title = pygame.font.Font("fonts/T.ttf", int(Winw * 8))
Timer = pygame.font.Font("fonts/T.ttf", int(Winw * 16))
Credit = pygame.font.Font("fonts/F.ttf", int(Winw * 4))
def Stop(self):
    self.living = False

pygame.mixer.init()
beep = pygame.mixer.Sound("sounds/beep.mp3")
beep.set_volume(1.0)
#PAUSE = 3
def main():
    
    #lb = LightBike()
    #lb2 = LightBike2()
    #lb3 = LightBike3()
    #Sprites = pygame.sprite.Group(lb, lb2, lb3)
    PAUSE = 3
    pygame.mixer.music.load( 'sounds/gamemusic.mp3')
    pygame.mixer.music.play(-1)
    play = True
    while play:
        
        COL = pygame.time.get_ticks()
        CRED = Credit.render("Credit to Ghostshooter53" , False, ((COL/5) % 254, (COL/ 7) % 254, (COL/9) % 254))
        TITLE = Title.render("TRON", False, ((COL/5) % 254, (COL/ 7) % 254, (COL/9) % 254))
        STATS = Stats.render("A Game By Quotex", False, ((COL/5) % 254, (COL/ 7) % 254, (COL/9) % 254))
        pygame.event.set_blocked((pygame.MOUSEMOTION, pygame.MOUSEBUTTONUP, pygame.MOUSEBUTTONDOWN))
        if pygame.key.get_pressed()[pygame.K_ESCAPE]:
            play = False
        if lb.living == False:
            if lb2.living == False:
                if lb3.living == False:
                    if lb4.living == False:
                        lb.begin()
                        lb2.begin()
                        lb3.begin()
                        lb4.begin()
                        PAUSE = 3
        clock.tick(CLOCKRATE)
        pygame.mouse.set_visible(False)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                play = False
        if lb.rect.centery >= screen.get_height()+ SPEED:
            Stop(lb)
        if lb.rect.centerx >= screen.get_width()+ SPEED:
            Stop(lb)
        if lb.rect.centery <= 0-SPEED:
            Stop(lb)
        if lb.rect.centerx <= 0-SPEED:
            Stop(lb)
        if lb2.rect.centery >= screen.get_height() + SPEED:
            Stop(lb2)
        if lb2.rect.centerx >= screen.get_width() + SPEED:
            Stop(lb2)
        if lb2.rect.centery <= 0 - SPEED:
            Stop(lb2)
        if lb2.rect.centerx <= 0 - SPEED:
            Stop(lb2)
        if lb3.rect.centery >= screen.get_height() + SPEED:
            Stop(lb3)
        if lb3.rect.centerx >= screen.get_width()+ SPEED:
            Stop(lb3)
        if lb3.rect.centery <= 0 - SPEED:
            Stop(lb3)
        if lb3.rect.centerx <= 0 - SPEED:
            Stop(lb3)
        if lb4.rect.centery >= screen.get_height() + SPEED:
            Stop(lb4)
        if lb4.rect.centerx >= screen.get_width()+ SPEED:
            Stop(lb4)
        if lb4.rect.centery <= 0 - SPEED:
            Stop(lb4)
        if lb4.rect.centerx <= 0 - SPEED:
            Stop(lb4)
            
                    
        #bgi = pygame.image.load('BlackBackground.gif')
        #screen.blit(bgi,(0,0))
        screen.fill((0,0,0))
        pygame.draw.lines(screen,((COL/5) % 254, (COL/ 7) % 254, (COL/9) % 254),False, Corners, int((Winw + Winh) / 3))
        
        #Sprites.update()
        screen.blit(TITLE, ( WINDOWW/2 - TITLE.get_width() /2 , WINDOWH/2 -TITLE.get_height()))
        screen.blit(STATS, (WINDOWW/2 - STATS.get_width()/2, WINDOWH/2 ))
        screen.blit(CRED, (WINDOWW/2 - CRED.get_width()/2, WINDOWH/2 + STATS.get_height()))
        Sprites.update()
        Sprites.draw(screen)
        while PAUSE > 0:
            screen.fill((0,0,0))
            beep.play()
            intro = Timer.render(str(PAUSE), False, ((COL/5) % 254, (COL/ 7) % 254, (COL/9) % 254))
            screen.blit(intro, ( WINDOWW/2 - TITLE.get_width() /2 , WINDOWH/2 -TITLE.get_height()))
            pygame.display.flip()
            PAUSE -= 1
            pygame.time.wait(750)
            
        pygame.display.flip()
        lb4.check()
    #return mouse cursor
    pygame.mouse.set_visible(True)
    

if __name__ == "__main__":
    main()
pygame.quit()
sys.exit()
        
