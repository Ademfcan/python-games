Winw, Winh, and SPEED all affect the window size. IF YOU CHANGE SPEED, Winh, OR Winw, IT IS POSSIBLE TO CREATE 
A SURFACE BIGGER THAN YOUR SCREEN CAN HANDLE. 
Winw and Winh are floats.
SPEED MUST BE an integer.

Run Tron.py to play